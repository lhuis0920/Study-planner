# FocusStudy - Study Planner & Dashboard

A study planner website built with HTML, CSS, and JavaScript featuring:
- Academic task tracker with priority, due date, course tagging, and duration estimates.
- Progress analytics dashboard with 7-day study consistency tracking and completion rate.
- Pomodoro focus study timer (25m Focus / 5m Break / 15m Long Rest).
- Browser `localStorage` persistence across all sessions.
- Dark & Light mode toggle.

## How to Run in VS Code:
1. Open this folder in **Visual Studio Code**.
2. Right-click on `index.html` and choose **"Open with Live Server"** (using the Live Server extension), or simply double-click `index.html` in your file explorer to open it directly in any web browser.
3. Your tasks and focus sessions are automatically saved to your browser's local storage.
